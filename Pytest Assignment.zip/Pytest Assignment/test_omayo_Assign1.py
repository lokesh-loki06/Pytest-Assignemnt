from selenium import webdriver
from selenium.webdriver.common.by import By


# 1.Text Area Field Two - print the text cat from this textfield
# 2. upload a file to upload file option (send keys function - this will need the location of file to send )
# 3. get the title of the page that opens after clicking "Open a popup window"
# 4. Print the age and place of Praveen from table as a tuple
# 5. input name and accept the prompt\alert after clicking : GetPrompt
# 6. select drop down : "doc3" from the drop-down on the left

class test_omayo1:
    def test(self):
        driver = webdriver.Chrome()

        driver.implicitly_wait(10)

        # Defining url
        url_omayo1 = "http://omayo.blogspot.com/"

        # open the webpage
        driver.get(url_omayo1)

        # maximize the window
        driver.maximize_window()

        # Finding xpath of text field two
        xpath_second_field = "//textarea[normalize-space()='The cat was playing in the garden.']"
        search = driver.find_element(By.XPATH, xpath_second_field)
        print(search.text[4:7])


go = test_omayo1()
go.test()
