from selenium import webdriver
from selenium.webdriver.common.by import By


# 1.Text Area Field Two - print the text cat from this textfield
# 2. upload a file to upload file option (send keys function - this will need the location of file to send )
# 3. get the title of the page that opens after clicking "Open a popup window"
# 4. Print the age and place of Praveen from table as a tuple
# 5. input name and accept the prompt\alert after clicking : GetPrompt
# 6. select drop down : "doc3" from the drop-down on the left

class test_omayo4:
    def test(self):
        driver = webdriver.Chrome()

        driver.implicitly_wait(10)

        # Defining url
        url_omayo4 = "http://omayo.blogspot.com/"

        # open the webpage
        driver.get(url_omayo4)

        # maximize the window
        driver.maximize_window()

        # Fetching data from web table
        """table = driver.find_element(By.ID,"table1")

        body = table.find_element(By.TAG_NAME, "tbody")

        cell = body.find_elements(By.TAG_NAME, "td")

        for i in cell:
            print(i.text)"""

        xpath_table = driver.find_elements(By.XPATH, "//table[@id='table1']//tr[3]")

        for i in xpath_table:
            print(i.text[8:])


go = test_omayo4()
go.test()
